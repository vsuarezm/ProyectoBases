package palacasa;

/**
 *
 * @author smorenor
 */
public class Palacasa {

    public static void main(String[] args) {

        
    }
    
}
