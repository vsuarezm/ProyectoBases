package palacasa;

/**
 *
 * @author Usuario
 */
import java.sql.*;
import java.util.Calendar;

public class Acciones {

    Connection conn;
    Statement stm;
    ResultSet rs;
    String lastError;

    public boolean ingresar(String usuario, String contrasena) {
        try {
            String url = "jdbc:mysql://localhost:3306/palacasa?userTimeZone=true&serverTimezone=UTC";
            String username = "root";
            String password = "zftUYR85";
            Connection connection = DriverManager.getConnection(url, username, password);
            Statement statement = connection.createStatement();
            ResultSet rs;
            rs = statement.executeQuery("SELECT * FROM administradores");
            while (rs.next()) {
                if ((rs.getString(1).equals(usuario)) && (rs.getString(3).equals(contrasena))) {
                    return true;
                }
            }
            statement.close();
            connection.close();
        } catch (SQLException ex) {
            System.out.println(ex);
        }
        return false;
    }

    public void registrarAdm(String usuario, String email, String contrasena, String nombre) {
        try {
            String url = "jdbc:mysql://localhost:3306/palacasa?userTimeZone=true&serverTimezone=UTC";
            String username = "root";
            String password = "zftUYR85";

            Connection connection = DriverManager.getConnection(url, username, password);

            PreparedStatement statement = connection.prepareStatement("INSERT INTO administradores(usuario, email, contrasena, nombre) VALUES (?,?,?,?)");

            statement.setString(1, usuario);
            statement.setString(2, email);
            statement.setString(3, contrasena);
            statement.setString(4, nombre);
            statement.executeUpdate();
            statement.close();
            connection.close();
        } catch (SQLException ex) {
            System.out.println(ex);

        }
    }

    public void registrarCliente(String idCliente, String nombreCliente, String fecha_nacimiento, String idSucursal) {
        try {
            String url = "jdbc:mysql://localhost:3306/palacasa?userTimeZone=true&serverTimezone=UTC";
            String username = "root";
            String password = "zftUYR85";

            Connection connection = DriverManager.getConnection(url, username, password);

            PreparedStatement statement = connection.prepareStatement("INSERT INTO cliente(idCliente, nombreCliente, fecha_nacimiento, idSucursal) VALUES (?,?,?,?)");

            statement.setString(1, idCliente);
            statement.setString(2, nombreCliente);
            statement.setString(3, fecha_nacimiento);
            statement.setString(4, idSucursal);
            statement.executeUpdate();
            statement.close();
            connection.close();
        } catch (SQLException ex) {
            System.out.println(ex);

        }
    }

    public void registrarClientePremium(String idClientePremium, String nombreCliente, String fecha_nacimiento, String cantidad_puntos, String numero_tarjeta, String idSucursal) {
        try {
            String url = "jdbc:mysql://localhost:3306/palacasa?userTimeZone=true&serverTimezone=UTC";
            String username = "root";
            String password = "zftUYR85";
            Connection connection = DriverManager.getConnection(url, username, password);

            PreparedStatement statement = connection.prepareStatement("INSERT INTO cliente(idClientePremium, nombreCliente, fecha_nacimiento, cantidad_puntos,numero_tarjeta,idSucursal) VALUES (?,?,?,?,?,?)");

            statement.setString(1, idClientePremium);
            statement.setString(2, nombreCliente);
            statement.setString(3, fecha_nacimiento);
            statement.setString(4, cantidad_puntos);
            statement.setString(5, numero_tarjeta);
            statement.setString(6, idSucursal);
            statement.executeUpdate();
            statement.close();
            connection.close();
        } catch (SQLException ex) {
            System.out.println(ex);

        }
    }

    public boolean verificarSiExisteCliente(String idCliente) {
        try {
            String url = "jdbc:mysql://localhost:3306/palacasa?userTimeZone=true&serverTimezone=UTC";
            String username = "root";
            String password = "zftUYR85";
            Connection connection = DriverManager.getConnection(url, username, password);
            Statement statement = connection.createStatement();
            // verificar si existe el cliente
            ResultSet rs;
            rs = statement.executeQuery("SELECT * FROM cliente");
            while (rs.next()) {
                if ((rs.getString(1).equals(idCliente))) {
                    return true;
                }
            }
            statement.close();
            connection.close();
        } catch (SQLException ex) {
            System.out.println(ex);

        }
        return false;
    }

    public boolean verificarSiExisteSucursal(String nombreSucursal) {
        try {
            String url = "jdbc:mysql://localhost:3306/palacasa?userTimeZone=true&serverTimezone=UTC";
            String username = "root";
            String password = "zftUYR85";
            Connection connection = DriverManager.getConnection(url, username, password);
            Statement statement = connection.createStatement();
            // verificar si esa sucursal ya existe
            ResultSet rs;
            rs = statement.executeQuery("SELECT * FROM sucursal");
            while (rs.next()) {
                if ((rs.getString(2).equals(nombreSucursal))) {
                    return true;
                }
            }
            statement.close();
            connection.close();
        } catch (SQLException ex) {
            System.out.println(ex);

        }
        return false;
    }
    
    public boolean verificarSiExisteProducto(String nombreProducto) {
        try {
            String url = "jdbc:mysql://localhost:3306/palacasa?userTimeZone=true&serverTimezone=UTC";
            String username = "root";
            String password = "zftUYR85";
            Connection connection = DriverManager.getConnection(url, username, password);
            Statement statement = connection.createStatement();
            // verificar si esa sucursal ya existe
            ResultSet rs;
            rs = statement.executeQuery("SELECT * FROM producto");
            while (rs.next()) {
                if ((rs.getString(2).equals(nombreProducto))) {
                    return true;
                }
            }
            statement.close();
            connection.close();
        } catch (SQLException ex) {
            System.out.println(ex);

        }
        return false;
    }
    
    public boolean verificarSiExisteProveedor(String nombreProveedor) {
        try {
            String url = "jdbc:mysql://localhost:3306/palacasa?userTimeZone=true&serverTimezone=UTC";
            String username = "root";
            String password = "zftUYR85";
            Connection connection = DriverManager.getConnection(url, username, password);
            Statement statement = connection.createStatement();
            // verificar si esa sucursal ya existe
            ResultSet rs;
            rs = statement.executeQuery("SELECT * FROM proveedor");
            while (rs.next()) {
                if ((rs.getString(3).equals(nombreProveedor))) {
                    return true;
                }
            }
            statement.close();
            connection.close();
        } catch (SQLException ex) {
            System.out.println(ex);

        }
        return false;
    }
    
    
    

    public boolean añadirSucursales(String nombreSucursal, String nombreCiudad) {
        try {
            String url = "jdbc:mysql://localhost:3306/palacasa?userTimeZone=true&serverTimezone=UTC";
            String username = "root";
            String password = "zftUYR85";
            Connection connection = DriverManager.getConnection(url, username, password);

            PreparedStatement statement = connection.prepareStatement("INSERT INTO sucursal(nombreSucursal, String nombreCiudad) VALUES (?,?)");
            statement.setString(2, nombreSucursal);
            statement.setString(3, "1");
            statement.setString(4, nombreCiudad);
            statement.executeUpdate();
            statement.close();
            connection.close();

        } catch (SQLException ex) {
            System.out.println(ex);

        }
        return true;
    }

    public boolean eliminarSucursal(String nombreSucursal) {
        try {
            String url = "jdbc:mysql://localhost:3306/palacasa?userTimeZone=true&serverTimezone=UTC";
            String username = "root";
            String password = "zftUYR85";
            Connection connection = DriverManager.getConnection(url, username, password);

            PreparedStatement statement = connection.prepareStatement("DELETE FROM sucursal WHERE nombreSucursal = '" + nombreSucursal + "'");
            statement.executeUpdate();
            statement.close();
            connection.close();
        } catch (SQLException ex) {
            System.out.println(ex);

        }
        return false;
    }


    public void eliminarCliente(String idCliente) {
        try {
            String url = "jdbc:mysql://localhost:3306/palacasa?userTimeZone=true&serverTimezone=UTC";
            String username = "root";
            String password = "zftUYR85";
            Connection connection = DriverManager.getConnection(url, username, password);

            PreparedStatement statement = connection.prepareStatement("DELETE FROM cliente WHERE idCliente = " + idCliente);
            statement.executeUpdate();
            statement.close();
            connection.close();
        } catch (SQLException ex) {
            System.out.println(ex);

        }
    }

    public void eliminarClienteP(String idCliente) {
        try {
            String url = "jdbc:mysql://localhost:3306/palacasa?userTimeZone=true&serverTimezone=UTC";
            String username = "root";
            String password = "zftUYR85";
            Connection connection = DriverManager.getConnection(url, username, password);

            PreparedStatement statement = connection.prepareStatement("DELETE FROM cliente_premium WHERE idClientePremium = " + idCliente);
            statement.executeUpdate();
            statement.close();
            connection.close();
        } catch (SQLException ex) {
            System.out.println(ex);

        }

    }


    public void compraCli(String idCliente) {
        try {
            String url = "jdbc:mysql://localhost:3306/palacasa?userTimeZone=true&serverTimezone=UTC";
            String username = "root";
            String password = "zftUYR85";
            Connection connection = DriverManager.getConnection(url, username, password);
            Statement statement = connection.createStatement();
            ResultSet rs;

            rs = statement.executeQuery("SELECT idCompra FROM compra WHERE idCliente = " + idCliente);
            while (rs.next()) {
                compr(rs.getString(1));
            }
            statement.close();
            connection.close();
        } catch (SQLException ex) {
            System.out.println(ex);
        }
    }
    
    public void compr(String idCompra) {
        try {
            String url = "jdbc:mysql://localhost:3306/palacasa?userTimeZone=true&serverTimezone=UTC";
            String username = "root";
            String password = "zftUYR85";
            Connection connection = DriverManager.getConnection(url, username, password);
            Statement statement = connection.createStatement();
            ResultSet rs;

            Compras comp = new Compras();
            rs = statement.executeQuery("SELECT * FROM compra_producto WHERE idCompraProducto = " + idCompra);
            while (rs.next()) {
                comp.com(rs.getString(3), rs.getString(4));
            }
            statement.close();
            connection.close();
        } catch (SQLException ex) {
            System.out.println(ex);
        }
    }
    
    
    
    
    public boolean añadirProducto(String nombreProducto, String idProveedor, String peso, String precio, String fecha_ven) {
        try {
            String url = "jdbc:mysql://localhost:3306/palacasa?userTimeZone=true&serverTimezone=UTC";
            String username = "root";
            String password = "zftUYR85";
            Connection connection = DriverManager.getConnection(url, username, password);

            PreparedStatement statement = connection.prepareStatement("INSERT INTO producto(nombreProducto, idProveedor, peso, precio, peso, fecha_ven ) VALUES (?,?,?,?,?,?)");
            statement.setString(2, nombreProducto);
            statement.setString(3, idProveedor);
            statement.setString(4, peso);
            statement.setString(5, precio);
            statement.setString(6, fecha_ven);
            statement.executeUpdate();
            statement.close();
            connection.close();

        } catch (SQLException ex) {
            System.out.println(ex);

        }
        return true;
    }

    public boolean eliminarProducto(String nombreProducto) {
        try {
            String url = "jdbc:mysql://localhost:3306/palacasa?userTimeZone=true&serverTimezone=UTC";
            String username = "root";
            String password = "zftUYR85";
            Connection connection = DriverManager.getConnection(url, username, password);

            PreparedStatement statement = connection.prepareStatement("DELETE FROM producto WHERE nombreProducto = '" + nombreProducto + "'");
            statement.executeUpdate();
            statement.close();
            connection.close();
        } catch (SQLException ex) {
            System.out.println(ex);

        }
        return false;
    }

    public boolean productoConsul(String codCliente) {
        return false;
    }
    
    
    
     public boolean añadirProveedor(String nombreProveedor, String ciudad) {
        try {
            String url = "jdbc:mysql://localhost:3306/palacasa?userTimeZone=true&serverTimezone=UTC";
            String username = "root";
            String password = "zftUYR85";
            Connection connection = DriverManager.getConnection(url, username, password);

            PreparedStatement statement = connection.prepareStatement("INSERT INTO proveedor(nombreProveedor, ciudad ) VALUES (?,?)");
            statement.setString(2, nombreProveedor);
            statement.setString(3, ciudad);

            statement.executeUpdate();
            statement.close();
            connection.close();

        } catch (SQLException ex) {
            System.out.println(ex);

        }
        return true;
    }

    public boolean eliminarProveedor (String nombreProveedor) {
        try {
            String url = "jdbc:mysql://localhost:3306/palacasa?userTimeZone=true&serverTimezone=UTC";
            String username = "root";
            String password = "zftUYR85";
            Connection connection = DriverManager.getConnection(url, username, password);

            PreparedStatement statement = connection.prepareStatement("DELETE FROM proveedor WHERE nombreProveedor = '" + nombreProveedor + "'");
            statement.executeUpdate();
            statement.close();
            connection.close();
        } catch (SQLException ex) {
            System.out.println(ex);

        }
        return false;
    }
    
    
    
    
    public void infoProv(String nombreProveedor) {
        try {
            String url = "jdbc:mysql://localhost:3306/palacasa?userTimeZone=true&serverTimezone=UTC";
            String username = "root";
            String password = "zftUYR85";
            Connection connection = DriverManager.getConnection(url, username, password);
            Statement statement = connection.createStatement();
            ResultSet rs;

            ProveedorInformacion f = new ProveedorInformacion();
            rs = statement.executeQuery("SELECT * FROM proveedor WHERE nombreProveedor = '" + nombreProveedor + "'");
            while (rs.next()) {
                f.pro(rs.getString(3), rs.getString(2));
            }
            statement.close();
            connection.close();
        } catch (SQLException ex) {
            System.out.println(ex);
        }
    }

    
     public void infoP(String nombreProducto) {
        try {
            String url = "jdbc:mysql://localhost:3306/palacasa?userTimeZone=true&serverTimezone=UTC";
            String username = "root";
            String password = "zftUYR85";
            Connection connection = DriverManager.getConnection(url, username, password);
            Statement statement = connection.createStatement();
            ResultSet rs;

            ProductoInformacion f = new ProductoInformacion();
            rs = statement.executeQuery("SELECT * FROM producto WHERE nombreProducto = '" + nombreProducto + "'");
            while (rs.next()) {
                f.nomPr(rs.getString(2), rs.getString(4), rs.getString(5), rs.getString(6));
            }
            statement.close();
            connection.close();
        } catch (SQLException ex) {
            System.out.println(ex);
        }
    }
     
     
     public String funcion() {
        try {
            String url = "jdbc:mysql://localhost:3306/palacasa?userTimeZone=true&serverTimezone=UTC";
            String username = "root";
            String password = "zftUYR85";
            Connection connection = DriverManager.getConnection(url, username, password);

            PreparedStatement sentencia = connection.prepareStatement("SELECT totalDeComprasUniversal()");
            ResultSet resultado =sentencia.executeQuery();
            resultado.next();
            String total = resultado.getString(1);

            
            resultado.close();
            connection.close();
            return total;

        } catch (SQLException ex) {
            System.out.println(ex);

        }
        return " ";
    }
    
     
     public void procedimiento(String id) {
        try {
            String url = "jdbc:mysql://localhost:3306/palacasa?userTimeZone=true&serverTimezone=UTC";
            String username = "root";
            String password = "zftUYR85";
            Connection connection = DriverManager.getConnection(url, username, password);

            CallableStatement sentencia = connection.prepareCall("CALL procedimiento(" + id + ")");
            sentencia.execute();
            connection.close();

        } catch (SQLException ex) {
            System.out.println(ex);

        }
    }
}
