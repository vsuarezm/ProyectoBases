package palacasa;

/**
 *
 * @author Usuario
 */
import java.sql.*;
import java.util.Calendar;

public class Acciones {

    Connection conn;
    Statement stm;
    ResultSet rs;
    String lastError;

    public void registrarAdm(String usuario, String email, String contrasena, String nombre) {
        try {
            String url = "jdbc:mysql://localhost:3306/palacasa?userTimeZone=true&serverTimezone=UTC";
            String username = "root";
            String password = "zftUYR85";

            Connection connection = DriverManager.getConnection(url, username, password);

            PreparedStatement statement = connection.prepareStatement("INSERT INTO administradores(usuario, email, contrasena, nombre) VALUES (?,?,?,?)");

            statement.setString(1, usuario);
            statement.setString(2, email);
            statement.setString(3, contrasena);
            statement.setString(4, nombre);
            statement.executeUpdate();
            statement.close();
            connection.close();
        } catch (SQLException ex) {
            System.out.println(ex);

        }
    }

    public void registrarCliente(String idCliente, String nombreCliente, String fecha_nacimiento, String idSucursal) {
        try {
            String url = "jdbc:mysql://localhost:3306/palacasa?userTimeZone=true&serverTimezone=UTC"; 
            String username = "root";
            String password = "zftUYR85";

            Connection connection = DriverManager.getConnection(url, username, password);

            PreparedStatement statement = connection.prepareStatement("INSERT INTO cliente(idCliente, nombreCliente, fecha_nacimiento, idSucursal) VALUES (?,?,?,?)");

            statement.setString(1, idCliente);
            statement.setString(2, nombreCliente);
            statement.setString(3, fecha_nacimiento);
            statement.setString(4, idSucursal);
            statement.executeUpdate();
            statement.close();
            connection.close();
        } catch (SQLException ex) {
            System.out.println(ex);

        }
    }

    public void registrarClientePremium(String idClientePremium, String nombreCliente, String fecha_nacimiento, String cantidad_puntos, String numero_tarjeta, String idSucursal) {
        try {
            String url = "jdbc:mysql://localhost:3306/palacasa?userTimeZone=true&serverTimezone=UTC"; 
            String username = "root";
            String password = "zftUYR85";
            Connection connection = DriverManager.getConnection(url, username, password);

            PreparedStatement statement = connection.prepareStatement("INSERT INTO cliente(idClientePremium, nombreCliente, fecha_nacimiento, cantidad_puntos,numero_tarjeta,idSucursal) VALUES (?,?,?,?,?,?)");

            statement.setString(1, idClientePremium);
            statement.setString(2, nombreCliente);
            statement.setString(3, fecha_nacimiento);
            statement.setString(4, cantidad_puntos);
            statement.setString(4, numero_tarjeta);
            statement.setString(2, idSucursal);
            statement.executeUpdate();
            statement.close();
            connection.close();
        } catch (SQLException ex) {
            System.out.println(ex);

        }
    }

    public boolean ingresar(String usuario, String contrasena) {
        try {
            String url = "jdbc:mysql://localhost:3306/palacasa?userTimeZone=true&serverTimezone=UTC";
            String username = "root";
            String password = "zftUYR85";
            Connection connection = DriverManager.getConnection(url, username, password);
            Statement statement = connection.createStatement();
            ResultSet rs;
            rs = statement.executeQuery("SELECT * FROM administradores");
            while (rs.next()) {
                if ((rs.getString(1).equals(usuario)) && (rs.getString(3).equals(contrasena))) {
                    return true;
                }
            }
            statement.close();
            connection.close();
        } catch (SQLException ex) {
            System.out.println(ex);
        }
        return false;
    }
    
    

    public boolean verificarSiExisteSucursal(String nombreSucursal) {
        try {
            String url = "jdbc:mysql://localhost:3306/palacasa?userTimeZone=true&serverTimezone=UTC";
            String username = "root";
            String password = "zftUYR85";
            Connection connection = DriverManager.getConnection(url, username, password);
            Statement statement = connection.createStatement();
            // verificar si esa sucursal ya existe
            ResultSet rs;
            rs = statement.executeQuery("SELECT * FROM sucursal");
            while (rs.next()) {
                if (!(rs.getString(2).equals(nombreSucursal))) {
                    return true;
                }
            }
            statement.close();
            connection.close();
        } catch (SQLException ex) {
            System.out.println(ex);

        }
        return false;
    }

    public boolean añadirSucursales(String nombreSucursal, String idCadena, String nombreCiudad) {
        try {
            String url = "jdbc:mysql://localhost:3306/palacasa?userTimeZone=true&serverTimezone=UTC";
            String username = "root";
            String password = "zftUYR85";
            Connection connection = DriverManager.getConnection(url, username, password);
            
            PreparedStatement statement = connection.prepareStatement("INSERT INTO sucursal(nombreSucursal, String idCadena, String nombreCiudad) VALUES (?,?,?)");
            statement.setString(1, nombreSucursal);
            statement.setString(2, idCadena);
            statement.setString(3, nombreCiudad);
            statement.executeUpdate();
            statement.close();
            connection.close();
            

        } catch (SQLException ex) {
            System.out.println(ex);

        }
        return true;
    }
    
    
    public boolean eliminarSucursal(String nombreSucursal) {
        try {
            String url = "jdbc:mysql://localhost:3306/palacasa?userTimeZone=true&serverTimezone=UTC";
            String username = "root";
            String password = "zftUYR85";
            Connection connection = DriverManager.getConnection(url, username, password);

            PreparedStatement statement = connection.prepareStatement("DELETE * FROM sucursal WHERE nombreSucursal = '" + nombreSucursal + "'");
            statement.executeUpdate();
            statement.close();
            connection.close();
        } catch (SQLException ex) {
            System.out.println(ex);

        }
        return false;
    }
    
    
     public void clientesDeSucur(String nombreSucursal) {
        try {
            String url = "jdbc:mysql://localhost:3306/palacasa?userTimeZone=true&serverTimezone=UTC";
            String username = "root";
            String password = "zftUYR85";
            Connection connection = DriverManager.getConnection(url, username, password);
            Statement statement = connection.createStatement();
            ResultSet rs, os;
            
            rs = statement.executeQuery("SELECT idSucursal FROM sucursal WHERE nombreSucursal = '" + nombreSucursal + "'");
            os = statement.executeQuery("SELECT * FROM cliente WHERE idSucursal = '" + rs + "'");
            while (os.next()) {
                
            }
            statement.close();
            connection.close();
        } catch (SQLException ex) {
            System.out.println(ex);

        }
    }
}
